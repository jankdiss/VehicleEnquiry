﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleEnquiry.Core.Utils
{
    public static class MetaData
    {
        public enum PriceType
        {
            POA,
            DAP,
            EGC
        }
    }
}
